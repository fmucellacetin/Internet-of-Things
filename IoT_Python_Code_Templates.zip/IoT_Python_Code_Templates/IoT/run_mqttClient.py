from django.core.management.base import BaseCommand, CommandError
from myapp.models import *

import os
import sys
import django
import json
import paho.mqtt.client as mqtt


class Command(BaseCommand):
    help = 'Invokes the mqtt client and subscribes to the thingspeak server'

    def handle(self, *args, **options):

    # ---- Enter your code below.......!