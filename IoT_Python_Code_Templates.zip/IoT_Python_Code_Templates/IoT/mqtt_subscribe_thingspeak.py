#!/usr/bin/env python

import time
import os
import requests
import json
import paho.mqtt.client as mqtt


def on_connect(client, userdata, flags, rc):
    print("Connected with result code: " + str(rc))


def on_message(client, userdata, message):
    print("message topic:       " + message.topic)
    print("message received:    " + str(message.payload.decode("utf-8")))
    msg = json.loads(str(message.payload.decode("utf-8")))

    channel =      msg['channel_id'] 
    creationDate = msg['created_at']
    entryNumber =  msg['entry_id']
    humidity =     msg['field1']
    temperature =  msg['field2']
    accelx =       msg['field3']
    accely =       msg['field4']
    accelz =       msg['field5']
    latitude =     msg['field6']
    longitude =    msg['field7']


def on_log(client, userdata, level, buf):
    print("log: " + buf)

# ThingSpeak MQTT Broker: do not change
THINGS_DEVICE_MQTTSERV = "mqtt3.thingspeak.com"

#Channel ID: Enter your channel id!
CHANNELID = "12345678"

#ThingSpeak Device user name: Enter your personal user name!
THINGS_DEVICE_USERNAME = "UUcccGGGvvvGGGvv1231"

#ThingSpeak Device password: Enter your password!
THINGS_DEVICE_PASSWORD = "AAaaaBBBcccDDDxx434"

#ThingSpeak Device client id: Enter the client id!
CLIENT_NAME = "UUcccGGGvvvGGGvv1231"

#ThingSpeaks standard MQTT port number: do not change
PORT=1883

#Some additional parameters: leave these values unchanged
KEEPALIVE=600
QOS_LEVEL=0

#---->
#Insert your code: 
#use the predefined parameters,
#create a mqtt paho client 
#and attach the appropriate callback functions;
#don't forget to invoke the "username_pw_set()" function 
#with the username and password 
#in advance to the call of the "connect()" function;
#subscribe to your ThingSpeak channel
#and use "loop_forever()" at the end of your program
#instead of the loop_start()/loop_stop() method!




